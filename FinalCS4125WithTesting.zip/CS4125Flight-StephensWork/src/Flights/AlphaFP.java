/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Flights;

/**
 *
 * @author Cailean
 */
public class AlphaFP extends Flight{
    
    public AlphaFP(){
        setFirstPrice(500);
        setBusinessPrice(400);
        setEconomicPrice(250);
        setBaggagePrice(30);
    }
    
}
