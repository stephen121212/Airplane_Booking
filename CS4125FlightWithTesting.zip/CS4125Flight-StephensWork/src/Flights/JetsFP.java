/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Flights;

/**
 *
 * @author Cailean
 */
public class JetsFP extends Flight{
    
    public JetsFP(){
        setFirstPrice(300);
        setBusinessPrice(200);
        setEconomicPrice(100);
        setBaggagePrice(20);
    }
    
}
